package main;

public class Train {

	public static final int TOTAL_PASSENGERS = 10;
	public Rider[] passengers;
	public int passengerIndex;
	
	public Train(String currentStation, int direction) {
		
	}
	
	public boolean goingNorth() {
		return false;
	}
	
	public void swapDirection() {
		
	}
	
	public String currentPassengers() {
		return null;
	}
	
	public boolean addPassenger(Rider r) {
		return false;
	}
	
	public boolean hasSpaceForPassengers() {
		return false;
	}
	
	public String disembarkPassengers() {
		return null;
	}
	
	public void updateStation(String s) {
		
	}
	
	public String getStation() {
		return null;
	}
	
	@Override
	public String toString() {
		return null;
	}
}
