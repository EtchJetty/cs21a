package main;

public class DoubleLinkedList<T> {

	public DoubleLinkedList() {
		
	}
	
	public Node<T> getFirst() {
		return null;
	}
	
	
	public void insert(T element) {
		
	}
	
	public T delete(T key) {
		return null;
	}
	
	public T get(T key) {
		return null;
	}
	
	public int size() {
		return -1;
	}
	
	@Override
	public String toString() {
		return null;
	}
}
