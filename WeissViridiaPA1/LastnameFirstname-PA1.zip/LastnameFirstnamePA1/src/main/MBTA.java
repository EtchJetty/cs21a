package main;

public class MBTA {

	public static final int SOUTHBOUND = 1;
	public static final int NORTHBOUND = 0;
	
	static final int TIMES = 6;
	static Railway r;
	
	public static void main(String[] args) {
		
	}
	
	public static void runSimulation() {
		
	}
	
	public static void initTrains(String trainsFile) {
		
	}
	
	public static void initRiders(String ridersFile) {
		
	}
	
	public static void initStations(String stationsFile) {
		
	}
}
