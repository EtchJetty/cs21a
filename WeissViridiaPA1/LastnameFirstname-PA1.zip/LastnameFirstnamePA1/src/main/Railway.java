package main;

public class Railway {

	public DoubleLinkedList<Station> railway;
	public String[] stationNames;
	
	public Railway() {
		
	}
	
	public void addStation(Station s) {
		
	}
	
	public void addRider(Rider r) {
		
	}
	
	public void addTrain(Train t) {
		
	}
	
	public void setRiderDirection(Rider r) {
		
	}
	
	public String simulate() {
		return null;
	}
	
	@Override
	public String toString() {
		return null;
	}
}
