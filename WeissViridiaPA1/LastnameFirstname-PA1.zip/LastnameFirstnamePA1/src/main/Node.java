package main;

public class Node<T> {
	
	public Node(T data) {
		
	}
	
	public void setData(T data) {
		
	}
	
	public void setNext(Node<T> next) {
		
	}
	
	public void setPrev(Node<T> prev) {
		
	}
	
	public Node<T> getNext() {
		return null;
	}
	
	public Node<T> getPrev() {
		return null;
	}
	
	public T getData() {
		return null;
	}
	
	@Override
	public String toString() {
		return null;
	}
}
