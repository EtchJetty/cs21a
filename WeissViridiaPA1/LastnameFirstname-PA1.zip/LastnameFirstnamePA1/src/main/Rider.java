package main;

public class Rider {

	public Rider(String riderID, String startingStation, String destinationStation) {
		
	}
	
	public String getStarting() {
		return null;
	}
	
	public String getDestination() {
		return null;
	}
	
	public String getRiderID() {
		return null;
	}
	
	public boolean goingNorth() {	
		return false;
	}
	
	public void swapDirection() {
		
	}
	
	@Override
	public String toString() {
		return null;
	}
	
	@Override
	public boolean equals(Object s) {
		return false;
	}
}
